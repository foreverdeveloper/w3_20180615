Ext.define('Device.controller.Orientation', {
    extend: 'Ext.app.Controller',

    config: {
        orientationView: 'orientation'
    }
});
